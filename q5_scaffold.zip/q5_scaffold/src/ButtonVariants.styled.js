import styled from "styled-components";

export const ButtonView = styled.button`
background-color:${(props) => props.bg};
color:${(props)=>props.color}
`